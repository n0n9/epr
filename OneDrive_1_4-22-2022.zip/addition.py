# python program to add two numbers

# take inputs
num1 = 5
num2 = 10

# add two numbers
sum = num1 + num2

# displaying the addition result
print('{0} + {1} = {2}'.format(num1, num2, sum))
