# Python program to find average of five numbers

# take inputs
num1 = float(input('Enter first number: '))
num2 = float(input('Enter second number: '))
num3 = float(input('Enter third number: '))
num4 = float(input('Enter four number: '))
num5 = float(input('Enter fifth number: '))

# calculate average
avg = (num1 + num2 + num3 + num4 + num5) / 5

# print average value
print('The average of numbers = %0.2f' %avg)