# Python program to print numbers from 1 to 10

print('Numbers from 1 to 10:')
for n in range(1, 11):
   print(n, end=' ')