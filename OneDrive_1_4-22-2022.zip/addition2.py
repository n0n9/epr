# python program to add two numbers provided by the user

# store input numbers
num1 = input('Enter First Number: ')
num2 = input('Enter Second Number: ')

# add two numbers
# User might also enter float numbers
sum = float(num1) + float(num2)

# displaying the adding result
# value will print in float
print('The sum of numbers {0} and {1} is {2}'.format(num1, num2, sum))
