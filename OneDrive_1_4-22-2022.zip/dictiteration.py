D = {'name': 'Bob',
     'age': 25,
     'job': 'Dev'}

for x in D:
    print(x)
# Prints name age job

for x in D:
    print(D[x])
# Prints Bob 25 Dev