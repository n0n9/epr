# Python program to convert decimal to binary

# take input
num = int(input('Enter any decimal number: '))

# display result
print('Binary value:', bin(num))