# Python program to add two numbers in one line
# Without using any variables

print('The sum is %.2f' %(float(input('Enter First Number: ')) 
            + float(input('Enter Second Number: '))))

      