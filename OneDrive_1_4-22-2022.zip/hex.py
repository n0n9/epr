# Python program to convert decimal to hexadecimal

# take inputs
num = int(input('Enter a decimal number: '))

# display result
print('HexaDecimal value = ', hex(num))